<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://local.onlinecampus-pflege.de/moodle
 *
 * @package    block
 * @subpackage myoverview
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addtofavourites'] = 'Nugget als Favorit markieren';
$string['aria:allcourses'] = 'Alle Nuggets (außer aus Ansicht entfernte)';
$string['aria:allcoursesincludinghidden'] = 'Alle Nuggets anzeigen';
$string['aria:controls'] = 'Steuerungen der Nuggetübersicht';
$string['aria:courseactions'] = 'Aktion für derzeitiges Nugget';
$string['aria:courseprogress'] = 'Nuggetfortschritt';
$string['aria:coursesummary'] = 'Text der Nuggetbeschreibung';
$string['aria:customfield'] = '{$a} Nuggets';
$string['aria:favourites'] = 'Favorisierte Nuggets anzeigen';
$string['aria:future'] = 'Künftige Nuggets anzeigen';
$string['aria:hiddencourses'] = 'Aus der Ansicht entfernte Nuggets';
$string['aria:inprogress'] = 'Laufende Nuggets anzeigen';
$string['aria:lastaccessed'] = 'Nugget nach letztem Zugriffsdatum anzeigen';
$string['aria:past'] = 'Vergangene Nuggets anzeigen';
$string['aria:removefromfavourites'] = 'Markierung als favorisiertes Nugget entfernen';
$string['aria:shortname'] = 'Nuggets nach Kurznamen sortieren';
$string['aria:title'] = 'Nuggets nach Nuggetnamen sortieren';
$string['courseprogress'] = 'Nuggetfortschritt:';
$string['hidden'] = 'Aus der Ansicht entfernte Nuggets';
$string['hidecourse'] = 'Nugget aus Ansicht entfernen';
$string['pluginname'] = 'Nuggetübersicht';
$string['removefromfavourites'] = 'Nugget aus den Favoriten entfernen';
$string['searchcourses'] = 'Nuggets suchen';
$string['shortname'] = 'Kurzer Nuggetname';
$string['show'] = 'Nugget in Ansicht anzeigen';
$string['sortbyshortname'] = 'Sortiert nach kurzem Nuggetnamen';
$string['sortbytitle'] = 'Sortiert nach Nuggetname';
$string['title'] = 'Nuggetname';
