<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://local.onlinecampus-pflege.de/moodle
 *
 * @package    tool
 * @subpackage lp
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['competenciesmostoftennotproficientincourse'] = 'Meist ungeübte Kompetenzen in diesem Nugget';
$string['coursecompetencies'] = 'Nuggetkompetenzen';
$string['coursesusingthiscompetency'] = 'Mit dieser Kompetenz verlinkte Nuggets';
$string['findcourses'] = 'Nuggets finden';
$string['linkedcourses'] = 'Verlinkte Nuggets';
$string['linkedcourseslist'] = 'Verlinkte Nuggets:';
$string['modcompetencies'] = 'Nuggetkompetenzen';
$string['modcompetencies_help'] = 'Nuggetkompetenzen, die mit dieser Aktivität verlinkt sind';
$string['nocompetenciesincourse'] = 'Für dieses Nugget sind keine Kompetenzen verlinkt.';
$string['nolinkedcourses'] = 'Zu dieser Kompetenz sind keine Nuggets verlinkt.';
$string['uponcoursecompletion'] = 'Bei Nuggetabschluss:';
$string['xcompetencieslinkedoutofy'] = '{$a->x} von {$a->y} Kompetenzen sind mit Nuggets verlinkt';
