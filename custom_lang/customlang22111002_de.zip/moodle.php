<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://local.onlinecampus-pflege.de/moodle
 *
 * @package    core
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['availablecourses'] = 'Nuggetliste';
$string['backtocourselisting'] = 'Zurück zur Nuggetliste';
$string['bycourseorder'] = 'Sortiert nach Nuggets';
$string['categories'] = 'Modulbereiche';
$string['categoriesandcourses'] = 'Nugget und Modulbereiche';
$string['category'] = 'Modulbereich';
$string['choosecourse'] = 'Nugget wählen';
$string['contentexport_aboutthiscourse'] = 'Nuggetbeschreibung';
$string['continuetocourse'] = 'Klicken Sie hier, um in Ihr Nugget zu gelangen';
$string['course'] = 'Nugget';
$string['coursecategories'] = 'Nuggetbereiche';
$string['coursecategory'] = 'Nuggetbereich';
$string['coursedetails'] = 'Nuggetdetails';
$string['courseduration'] = 'Nuggetdauer';
$string['courseinfo'] = 'Nuggetinformation';
$string['coursenotaccessible'] = 'Dieses Nugget ist nicht öffentlich zugänglich.';
$string['courseoverview'] = 'Nuggetbeschreibung';
$string['courseoverviewfiles'] = 'Nuggetbild';
$string['courses'] = 'Nuggets';
$string['coursesearch'] = 'Nuggets suchen';
$string['coursesectionsummaries'] = 'Beschreibung zu Nuggetabschnitten';
$string['coursestart'] = 'Nuggetbeginn';
$string['coursesummary'] = 'Nuggetbeschreibung';
$string['coursetitle'] = 'Nugget: {$a->course}';
$string['deletecategoryempty'] = 'Dieser Modulbereich ist leer.';
$string['enddate'] = 'Nuggetende';
$string['entercourse'] = 'Hier klicken, um den Nugget zu betreten';
$string['eventcoursessearched'] = 'Nuggets gesucht';
$string['eventcourseviewed'] = 'Nugget angezeigt';
$string['eventmycoursesviewed'] = 'Meine Nuggets angezeigt';
$string['findmorecourses'] = 'Weitere Nuggets finden...';
$string['frontpagecategorynames'] = 'Modulbereiche';
$string['frontpagecourselist'] = 'Nuggetliste';
$string['frontpagecoursesearch'] = 'Nuggetsuche';
$string['frontpageenrolledcourselist'] = 'Eingeschrieben Nuggets';
$string['fulllistofcourses'] = 'Alle Nuggets';
$string['fullnamecourse'] = 'Vollständiger Nuggetname';
$string['mycourses'] = 'Meine Nuggets';
$string['searchcourses'] = 'Nuggets suchen';
$string['selectacourse'] = 'Nugget auswählen';
$string['showallcourses'] = 'Alle Nuggets anzeigen';
$string['showlistofcourses'] = 'Nuggetliste anzeigen';
$string['startdate'] = 'Nuggetbeginn';
$string['thiscategory'] = 'Dieser Modulbereich';
$string['viewallcourses'] = 'Alle Nuggets zeigen';
